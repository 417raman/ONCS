import logo from './logo.svg';
import './App.css';
import "../node_modules/bootstrap/dist/css/bootstrap.css"
import Home from "./components/pages/Home";
import About from './components/pages/About';
import Login from './components/pages/Login';
import Navbar from './components/pages/layout/Navbar';
import Footer from './components/pages/layout/Footer';
/* import { BrowserRouter as Router, Route, Routes } from 'react-router-dom'; */
import {BrowserRouter as Router,Route,Switch,Redirect} from "react-router-dom"
import Complain from './components/pages/Complain';
/* import PhoneInput from 'react-phone-number-input'; */
import User from './components/pages/User';
import Logout from './components/pages/layout/Logout';
import Feedback from './components/pages/layout/Feedback';
import AdminLayout from './components/pages/layout/AdminLayout';
import AdminDashboard from './components/pages/layout/AdminDashboard';


function App() {
   return (

    <div className="page-container"></div>,
    <div className="content-wrap">


      <Router>
        <div className="App">
          <Navbar />
          <Switch>
            <Route exact path="/" component={Home} />
            <Route path="/About" component={About} />
            <Route path="/Login" component={Login} />
            <Route path="/User" component={User} />
            <Route path="/Complain" component={Complain} />
            <Route path="/Feedback" component={Feedback}/>
            <Route path="/AdminDashboard" component={AdminDashboard} />
            <Route path="/Logout" component={Logout}/>
            
            <Redirect to ="/" />

          </Switch>


        </div>
      </Router>
      
      
      {/* <Footer /> */}
    </div>

  );
}

export default App;
