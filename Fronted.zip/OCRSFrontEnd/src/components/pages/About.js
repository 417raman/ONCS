import React from "react";
import images5 from "../images/images5.jpg";
import images2 from "../images/images2.jpg";
import Footer from "./layout/Footer";

function about() {
  return (
    <div>
      <div id="container">
        <div id="header">
          {/* <h1>About Us</h1> */}
        </div>
        <div id="wrapper">
          <div id="content">
            <h3>Who we are</h3>
            <p>
              Online crime reporting system which allows the user to file
              complaints or missing reports and keep a track of it. There are 3
              categories that a user can file; Complaint, Crime Report and
              Missing Report. This project will definitely help the police system
               in making the police work more efficient through equipping the police 
               with modern solutions i.e. it aims to ensure solutions and means for 
               the police officers that support their main activity.
                <br/>To file any of the above 3 complaints, the
              user should register in to the system and provide his right
              credentials to file them. The crime reporting system project also
              allows other users who doesn’t want to register but can check the
              crimes happening at his/her or any other area. 
              Offline i.e., the unregistered user can also take
              advantage of checking the missing person details, but he/she is
              refrained from getting complaints done by the users. The main 
              intent of this project is to upgrade the developing countries 
              police administration to the world standard by using modern 
              information and communication technologies. 
              <br/>We provide right cases to right persons
            </p> 
          </div>
        </div>
        <div id="navigation">
          <img src={images5} alt="save" width={223} height={200} />
          <img src={images2} alt="save" width={230} height={200} />
        </div>
      </div>
      <Footer />
    </div>
  );
}
export default about;