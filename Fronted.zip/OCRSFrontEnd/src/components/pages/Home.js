import React from "react";
import header_bckg from "../images/header_bckg.jpg";
import mw1 from "../images/mwcriminal/mw1.jfif";
import mw7 from "../images/mwcriminal/mw7.jfif";
import mw8 from "../images/mwcriminal/mw8.jfif";
import mw4 from "../images/mwcriminal/mw4.jfif";
import mw5 from "../images/mwcriminal/mw5.jfif";
import mw6 from "../images/mwcriminal/mw6.jfif";
/* import "./slider.css"; */
import miss1 from "../images/miss/miss1.jfif";
import miss2 from "../images/miss/miss2.jfif";
import miss3 from "../images/miss/miss3.jfif";
import miss4 from "../images/miss/miss4.jfif";
import miss5 from "../images/miss/miss5.jfif";
import miss6 from "../images/miss/miss6.jfif";
import { Link } from "react-router-dom"
import Crimev from "../videos/Crimev.mp4";
import Footer from "./layout/Footer";

function Home() {
  return (
    <div>
      <section>
        <div className="row">
          <div className="col-md-4-my-auto">
            <div className="form-group" py-3>
              <img src={header_bckg} alt="slider" width={1550} height={120} />
            </div>
          </div>
          <video autoPlay loop muted>
            <source src={Crimev} type="video/mp4" />
          </video>
        </div>
      </section>
      <section>
        <div id="nw">
          <div className="container">
            <div className="ticker">
              <div className="title">
                <h5>Breaking News</h5>
              </div>
            </div>
            <div className="news">
              <marque>
                <p>
                  -) Next round of voting commences today. <br/> -) Hijab row:
                  Prohibitory orders as Karnataka reopens schools <br/>-) Centre to
                  sell 5% stake in LIC<br/>-) And the most expensive overseas player
                  of the auction was… <br/>-) Psyche was the wife of which Roman god?<br/>
                  -) ISRO`s first launch mission of 2022 <br/>-) SBI defends its
                  response on defaulter ABG Shipyard <br/>-) Israel probes NSO
                  database over allegations of rogue wiretapping <br/>-) Chelsea win
                  maiden Club World Cup.
                </p>
              </marque>
            </div>
          </div>
        </div>
      </section>
      <section>
        <div>
          <h2 id="mw">Most Wanted Criminals</h2>
        </div>
        <div id="slider">
          <figure>
            <img src={mw1} alt="mw1" height={250} width={250} />
            <img src={mw7} alt="mw7" height={250} width={250} />
            <img src={mw8} alt="mw1" height={250} width={250} />
            <img src={mw4} alt="mw1" height={250} width={250} />
            <img src={mw5} alt="mw1" height={250} width={250} />
            <img src={mw6} alt="mw1" height={250} width={250} />
            <br />
          </figure>
        </div>
        <div>
          <h2 id="mw">Missing Persons</h2>
        </div>
        <div id="miss">
          <figure>
            <img src={miss1} alt="mw1" height={250} width={250} />
            <img src={miss2} alt="mw7" height={250} width={250} />
            <img src={miss3} alt="mw1" height={250} width={250} />
            <img src={miss4} alt="mw1" height={250} width={250} />
            <img src={miss5} alt="mw1" height={250} width={250} />
            <img src={miss6} alt="mw1" height={250} width={250} />
            <br />
          </figure>
        </div>
      </section>
      
     <Footer /> 
    </div>
  );
}
export default Home;