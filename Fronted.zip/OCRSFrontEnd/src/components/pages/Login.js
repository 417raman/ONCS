import React from "react";

function h(){
    console.log("Login Success")
} 

const Login = () => {

    
    return (
        <div>
            <section className="py-4 bg-info">
                <div className="container">
                    <div className="row">
                        <div className="col-md-4 my-auto">
                            <h4> Login</h4>
                        </div>
                        <div className="col-md-8 my-auto">
                            <h6 className="float-end"> Home / Login</h6>
                        </div>
                    </div>
                </div>
            </section >

            <section className="section">
                <div className="container w-50">
                    <div className="card shadow ">
                        <div className="card body" >
                            <div className="row">
                                <div className="center">
                                    <h6>Login Page</h6>
                                    <hr />
                                    <div className="form-group">
                                        <label className="mb-1">User Id</label>
                                        <input type="text" className="form-control" placeholder="Enter full name" />
                                    </div>

                                    <div class="form-group">
                                        <label for="exampleInputPassword1">Password</label>
                                        <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password" />
                                    </div>
                                    <div class="form-check">
                                        <input type="checkbox" class="form-check-input" id="exampleCheck1" />
                                        <label class="form-check-label" for="exampleCheck1">Admin</label>
                                    </div>

                                    <div className="form-group" py-3>
                                        
                                        <button type="button" onClick={() => h()} >Sign in</button>
                                        
                                    </div>
                                    
                                </div>


                            </div>
                        </div>
                    </div>
                </div>
            </section >
        </div>
    );
};

export default Login;