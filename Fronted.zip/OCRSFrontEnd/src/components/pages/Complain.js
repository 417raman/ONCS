import React, { useEffect, useState } from "react";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import axios from "axios";


function User() {
    const [validated, setValidated] = useState();
    function handleSubmit(e) {
        const form = e.currentTarget;
        console.log("In submit");
        if (form.checkValidity() === false) {
            e.stopPropagation();
            e.preventDefault();
            setValidated(true);
        }
        else {
            e.preventDefault();
            console.log("Validation complete");

            var email = e.target.email.value;
            var password = e.target.password.value;
            var userId = e.target.userId.value;
            var confirmPassword = e.target.confirmPassword.value;
            var mobile = e.target.mobile.value;
            var address = e.target.address.value;
            console.log(userId, email, address, mobile, password, confirmPassword);

            /* axios("https://localhost:44342/api/users", {
                method: "POST",
                data: { userId: userId, EmailId: email, Password: password, Mobilenumber: mobile, Address: address, ConfirmPassword: confirmPassword },
            })
                .then((response) => {
                    if (response.status === 201) {
                        console.log(response);

                    }
                })
                .catch((error) => {


                    console.log(error);
                }); */



        }
    }
    return (


        <Form noValidate validated={validated} onSubmit={handleSubmit}>
            <section className="py-4 bg-info">
                <div className="container">
                    <div className="row">
                        <div className="col-md-4 my-auto">
                            <h4> Complain Page</h4>
                        </div>
                        <div className="col-md-8 my-auto">
                            <h6 className="float-end"> Home / Complain</h6>
                        </div>
                    </div>
                </div>
            </section >

            <section className="section">
                <div className="container w-50">
                    <div className="card shadow ">
                        <div className="card body" ></div>
                        <Row className="mb-3">
                            <Form.Group md="4" controlId="validationCustom01">
                                <Form.Label>User Id</Form.Label>
                                <Form.Control
                                    required
                                    name="userId"
                                    type="text"
                                    placeholder="Enter Full name"
                                /* defaultValue="Mark" */
                                />
                                <Form.Control.Feedback>Looks good!</Form.Control.Feedback>
                            </Form.Group>
                        </Row>
                        <Row className="mb-3">
                            <Form.Group md="4" controlId="validationCustom02">
                                <Form.Label>Crime Type</Form.Label>
                                <Form.Control
                                    required
                                    type="text"
                                    name="crime type"
                                    placeholder="Enteer type of Crime"
                                /* defaultValue="Otto" */
                                />
                                <Form.Control.Feedback>Looks good!</Form.Control.Feedback>
                            </Form.Group>
                        </Row>
                        <Row className="mb-3">
                            <Form.Group md="4" controlId="validationCustomUsername">
                                <Form.Label>Address</Form.Label>

                                <Form.Control
                                    type="text"
                                    name="address"
                                    placeholder="Address"
                                    aria-describedby="inputGroupPrepend"
                                    required
                                />
                                <Form.Control.Feedback type="invalid">
                                    Please write your address.
                                </Form.Control.Feedback>

                            </Form.Group>
                        </Row>
                        <Row className="mb-3">
                            <Form.Group md="6" controlId="validationCustom03">
                                <Form.Label>Mobile Number</Form.Label>
                                <Form.Control type="digit" name="mobile" placeholder="Mobile Number" required />
                                <Form.Control.Feedback type="invalid">
                                    Please provide a mobile number.
                                </Form.Control.Feedback>
                            </Form.Group>
                        </Row>
                        <Row className="mb-3">
                            <Form.Group md="3" controlId="validationCustom04">
                                <Form.Label>Date</Form.Label>
                                <Form.Control type="int" placeholder="Enter Date in DD/MM/YYYY fromat" required />
                                <Form.Control.Feedback type="invalid">
                                    Please provide a date.
                                </Form.Control.Feedback>
                            </Form.Group>
                        </Row>
                        <Row className="mb-3">
                            <Form.Group md="3" controlId="validationCustom05">
                                <Form.Label>Time</Form.Label>
                                <Form.Control type="int" placeholder="Enter Time in HH:MM:SS format" required />
                                <Form.Control.Feedback type="invalid">
                                    Please provide a time.
                                </Form.Control.Feedback>
                            </Form.Group>
                        </Row>
                        <Row className="mb-3">
                            <Form.Group md="3" controlId="validationCustom05">
                                <Form.Label>Description</Form.Label>
                                <Form.Control textarea row="3" placeholder="Type about your situation here....." required />
                                <Form.Control.Feedback type="invalid">
                                    Please provide a Description about your crime.
                                </Form.Control.Feedback>
                            </Form.Group>
                        </Row>
                        <Form.Group className="mb-3">
                            <Form.Check
                                required
                                label="Agree to terms and conditions"
                                feedback="You must agree before submitting."
                                feedbackType="invalid"
                            />
                        </Form.Group>
                        <Row className="mb-3">
                            <div className="col-md-6">
                                <div className="form-group" py-3>
                                    <Button type="submit" className="btn-btn-primary">Submit</Button>
                                </div>
                            </div>
                            <div className="col-md-6">
                                <div className="form-group" py-3>
                                    <Button type="cancel" className="btn-btn-primary">Cancel</Button>
                                </div>
                            </div>
                        </Row>
                    </div>
                </div>
            </section>
        </Form >
    );





}

export default User;
