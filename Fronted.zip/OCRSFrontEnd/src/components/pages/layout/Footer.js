import React from 'react';
import "./Footer.css"
class Footer extends React.Component
{
    render(){
        return(
            <div className="main-footer">
                <div className="container">
                    <div className="row">
                        {/* Column1 */}
                        <div className="col">
                            <h3>ONLINE CRIME REPORTING SYSTEM</h3>
                            <h2>By</h2>
                            <ul className="list-unstyled">
                                <li>Anupriya.Sirvya@cognizant.com</li>
                                <li>Prince.Shrivastava@cognizant.com</li>
                                <li>Ajay.Reddy@cognizant.com</li>
                                <li>Pavan.Marrapu@cognizant.com</li>
                                <li>Raman.Singh3@cognizant.com</li>
                            </ul>
                        </div>
                    </div>
                    <hr />
                    <div className="row">
                        <p className="col-sm">
                            &copy;{new Date().getFullYear()} Online Crime Management System | All right reserved  | Terms of Service | Privacy
                        </p>
                    </div>

                </div>

            </div>
       );
   }
}

export default Footer;
