import React from "react";
import Navbar from "./Navbar";

 
export default function AdminLayout(props) {
  return (
    <>
      {/* <Navbar
        AdminLogin={props.AdminLogin}
        setAdminLoginStatus={props.setAdminLoginStatus}
      /> */}
      {props.children}
      {/* <div className="cotainer bg-primary text-white"> © Copyright, library management Feb 2022
        </div>`` */}
    </>
  );
}