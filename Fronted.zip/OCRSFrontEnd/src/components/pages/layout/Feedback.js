import { useState } from "react"
/* import "./styles.css"; */


export default function App() {
  const [modal, setModal] = useState(false)
  const [data, setData] = useState({
    name: "",
    email: "",
    feedback: ""
  })

  const handleChange = (e) => {
    const { name, value } = e.traget;

    setData({ ...data, [name]: value });
  };

  const HandleSubmit = (e) => {
    e.preventDefault()
    console.log(data)
  }
  return (
    <div >
      <section className="py-4 bg-info">
        <div className="container">
          <div className="row">
            <div className="col-md-4 my-auto">
              <h4> Feedback</h4>
            </div>
            <div className="col-md-8 my-auto">
              <h6 className="float-end"> Home / Feedback</h6>
            </div>
          </div>
        </div>
      </section >

      <section className="section">
        <div className="container w-50">
          <div className="card shadow ">
            <div className="card body" >

              <h1 className="h1">Feedback Form</h1>
              {!modal && (
                <button
                  className="btn btn-orange close-btn"
                  onClick={() => setModal((value) => !value)}
                >
                  User's Feedback
                </button>
              )}
              <div>
                {modal && (
                  <form className="feedback" onSubmit={HandleSubmit}>
                    <button
                      className="close-btn-form"
                      onClick={() => setModal((value) => !value)}
                    >
                      Click here to come out of this page......Thankuu!!
                    </button>
                    <div className="ml-rem">
                      <input
                        placeholder="Name"
                        name="name"
                        onChange={(e) => handleChange(e)}
                      />
                    </div>
                    <div>
                      <input
                        placeholder="Email"
                        name="email"
                        onChange={(e) => handleChange(e)}
                      />
                    </div>
                    <div className="ml-rem">
                      <input
                        placeholder="Feedback"
                        name="feedback"
                        onChange={(e) => handleChange(e)}
                      />
                    </div >
                    <button className="btn btn-green" onClick={HandleSubmit}>
                      Submit feedback
                    </button>
                  </form>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}