import React, { Component } from 'react'
/* import { baseUrl } from '../helpers'; */
import {Link} from 'react-router-dom'

class Logout extends React.Component {
/* logout = () => {
window.localStorage.clear();
window.location.href = baseUrl +"login";
}; */
render(){
return(
<Link onClick={this.logout} className="logout">Logout</Link>
)
}
}
export default Logout;