import React, { Component } from "react";
import AdminLayout from "./AdminLayout";



import 'bootstrap/dist/css/bootstrap.min.css';
class AdminDashboard extends Component {
  constructor(props) {
    super(props);
  }
  state = {};
  render() {
    return (
      <>
        <AdminLayout
          AdminLogin={this.props.AdminLogin}
          setAdminLoginStatus={this.props.setAdminLoginStatus}
        >

          <h2>Admin Dashboard</h2>
          <div className="row"

            style={{
              display: "flex",
              height: "80vh",
              justifyContent: "flex-start",
              flexDirection: "inherit",
              alignItems: "center",

              backgroundImage: "url('https://cutewallpaper.org/img/1.jpg')",

              opacity: "1",

            }}

          >
            {/* background: url('./assets/2132976.jpg')  no-repeat center/cover; */}


            <div class="container text-primary p-5 my-5 border"
              style={{
                display: "flex",
                height: "20vh",
                justifyContent: "flex-start",
                flexDirection: "inherit",
                alignItems: "center",
                fontSize: 30,
                width: "80%",

                backgroundColor: "pink",
              }}><b>Total no. of Cases: 15</b></div>

            <div class="container p-5 my-5 bg-success text-white" style={{
              display: "flex",
              height: "20vh",
              justifyContent: "flex-start",
              flexDirection: "inherit",
              alignItems: "center",
              fontSize: 30,
              width: "80%",

              backgroundColor: "red"
            }}>Total no. of Missing Peoples: 5</div>

            {/* <div>
                  < button href="C:\Users\HP\Desktop\Crimes-Reporting-and-Missing-People-Finder-App-in-React\src\components\login.js">Click</button>
              </div> */}
              
          </div>
          <div className="row">
            <a href="http://localhost:3002/signup">
              <button style={{ 'margin': '24px auto' }}>Dashboard</button>
            </a>
            </div>
        </AdminLayout>
      </>
    );
  }
}

export default AdminDashboard;